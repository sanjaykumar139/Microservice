﻿namespace BuildingBlocks.Filters;

public enum FieldTypeEnum
{
    Default,
    DateTime,
    Money
}