﻿namespace BuildingBlocks.Filters;

public enum LogicOperationEnum
{
    Or,
    And
}