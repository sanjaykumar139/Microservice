﻿namespace BuildingBlocks.Filters;

public enum ComparisonOperationEnum
{
    Equal,
    NotEqual,
    GreaterThan,
    LessThan,
    Between

}
