﻿namespace Shared.Constants
{
    public static class ClaimsConstants
    {
        public const string UserId = "UserId";
        public const string RoleId = "RoleId";
        public const string PersonName = "PersonName";
    }
}
