﻿using MediatR;

namespace BuildingBlocks.Contracts
{
    public interface IQuery<out TResult> : IRequest<TResult>
    {

    }
}
