﻿using BuildingBlocks.Infrastructure.EventBus;
using MassTransit;

namespace BuildingBlocks.EventBus
{
    public interface IMassTransitConsumer<in T> : IConsumer<T> where T: IntegrationEvent 
    {
    }
}
