﻿using Autofac;
using User.Infrastructure;

namespace User.Api.Configuration
{
    internal class UserAutofacModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            builder.RegisterType<UserModule>()
                .As<IUserModule>()
                .InstancePerLifetimeScope();
        }
    }
}
