using Autofac;
using Autofac.Extensions.DependencyInjection;
using BuildingBlocks.Application;
using BuildingBlocks.Filters;
using FluentValidation.AspNetCore;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Server.Kestrel.Core;
using Microsoft.OpenApi.Models;
using Shared.Configurations;
using Shared.Constants;
using Shared.Extensions;
using User.Api.Configuration;
using User.Infrastructure.Configuration;

var builder = WebApplication.CreateBuilder(args);

ConfigureServices(builder);
var appSetting = InitializeApp(builder.Configuration);

ConfigureContainer(builder, appSetting);
builder.WebHost.UseSentry((options) =>
{
    options.Dsn = builder.Configuration["Sentry:Dns"];
    options.IncludeActivityData = true;
    options.AttachStacktrace = true;
    options.Debug = true;
    options.SendDefaultPii = true;
    options.MaxRequestBodySize = Sentry.Extensibility.RequestSize.Always;
    options.Environment = builder.Environment.EnvironmentName;
});

var app = builder.Build();
ConfigureApp(app, builder.Configuration.GetSection("SwaggerAuth"));
app.Run();

void ConfigureServices(WebApplicationBuilder builder)
{
    //Setting up request size
    builder.Services.Configure<KestrelServerOptions>(options =>
    {
        options.Limits.MaxRequestBodySize = int.MaxValue; // Set to 50 MB (adjust as needed)
    });
    //Setting FormData size limit
    builder.Services.Configure<FormOptions>(x =>
    {
        x.ValueLengthLimit = int.MaxValue;
        x.MultipartBodyLengthLimit = int.MaxValue;
        x.MultipartHeadersLengthLimit = int.MaxValue;
    });
    builder.Services.AddHttpContextAccessor();
    builder.Services.AddAuthentication();
    builder.Services.AddCors(o => o.AddPolicy("corsPolicy", builder =>
    {
        builder.SetIsOriginAllowedToAllowWildcardSubdomains()
               .AllowAnyOrigin()
               .AllowAnyMethod()
               .AllowAnyHeader();
    }));
    builder.Services.AddFluentValidation(mv => mv.RegisterValidatorsFromAssembly(AppDomain.CurrentDomain.Load("User.Application")));
    builder.Services.AddControllers(config => config.Filters.Add(typeof(ApiResultFilterAttribute)));
    builder.Services.AddEndpointsApiExplorer();
    builder.Services.AddRouting(options => options.LowercaseUrls = true);
    var swagconfig = builder.Configuration.GetSection("SwaggerAuth");
    ConfigSwagger(builder.Services, swagconfig);
    builder.Services.AddLogging(configure =>
    {
        configure.ClearProviders();
        configure.AddJsonConsole(opts =>
        {
            opts.TimestampFormat = "s";
        });
    });
    builder.Services.Configure<ApiBehaviorOptions>(config => config.SuppressModelStateInvalidFilter = false);
    builder.Services.Configure<AppSettings>(builder.Configuration.GetSection("AppSettings"));
    builder.Services.AddVersionSupport(builder.Configuration.GetSection("Version").Get<VersionSettings>());
    builder.Services.RegisterSessionManager();
}

AppSettings InitializeApp(IConfiguration configuration)
{
    IConfigurationSection appSettings = configuration.GetSection("AppSettings");
    var appSetting = appSettings.Get<AppSettings>();
    // Register service to discovery
    builder.Services.RegisterService(appSetting.ServiceConfig);

    //appSetting.RabitMQConfiguration.UserName = Environment.GetEnvironmentVariable(CommonEnvVariables.RabbitMQUserName) ?? string.Empty;
    //appSetting.RabitMQConfiguration.Password = Environment.GetEnvironmentVariable(CommonEnvVariables.RabbitMQPassword) ?? string.Empty;
    //appSetting.RabitMQConfiguration.HostName = Environment.GetEnvironmentVariable(CommonEnvVariables.RabbitMQHost) ?? string.Empty;
    //appSetting.RabitMQConfiguration.Port = Convert.ToUInt16(Environment.GetEnvironmentVariable(CommonEnvVariables.RabbitMQPort));
    return appSetting;
}
void ConfigSwagger(IServiceCollection serviceCollection, IConfigurationSection swagconfig)
{
    // Add SwaggerGen for API documentation
    serviceCollection.AddSwaggerGen(c =>
    {
        c.OperationFilter<SwaggerHeaderId>();
        c.AddSecurityDefinition("oauth2", new OpenApiSecurityScheme
        {
            Description = "Swagger Auth For CCA",
            Name = "oauth2",
            Type = SecuritySchemeType.OAuth2,
            Flows = new OpenApiOAuthFlows
            {
                AuthorizationCode = new OpenApiOAuthFlow
                {
                    AuthorizationUrl = new Uri(swagconfig["AuthorityEndPoint"] ?? string.Empty),
                    TokenUrl = new Uri(swagconfig["TokenEndpoint"] ?? string.Empty),
                    Scopes = new Dictionary<string, string>
                    {
                        { swagconfig["Scope"], "CCA.ReadWrite" }
                    }
                }
            }
        });
        c.AddSecurityRequirement(new OpenApiSecurityRequirement
        {
            {
                new OpenApiSecurityScheme
                {
                    Reference = new OpenApiReference { Type = ReferenceType.SecurityScheme, Id = "oauth2" }
                },
                new[] { swagconfig["Scope"] }
            }
        });
    });
}

void ConfigureContainer(WebApplicationBuilder builder, AppSettings appSetting)
{
    builder.Host.UseServiceProviderFactory(new AutofacServiceProviderFactory())
        .ConfigureContainer<ContainerBuilder>(b =>
        {
            b.RegisterModule(new UserAutofacModule());
            UserStartup.Initialize(appSetting, Environment.GetEnvironmentVariable(CommonEnvVariables.ConnectionString), null, builder.Configuration, builder.Environment);
        });
}

void ConfigureApp(WebApplication app, IConfigurationSection swagconfig)
{
    app.UseSentryTracing();
    SentrySdk.CaptureMessage($"Service started at: {DateTime.UtcNow}");
    app.UseCors("corsPolicy");

    app.UseHttpsRedirection();
    app.UseAuthentication();
    app.UseAuthorization();
    app.UseSwagger();
    app.UseSwaggerUI(options =>
    {
        options.DisplayRequestDuration();
        options.EnableTryItOutByDefault();

        options.OAuthClientId(swagconfig["ClientId"]);
        options.OAuthUsePkce();
        options.OAuthScopeSeparator(" ");
    });
    app.MapControllers();
}