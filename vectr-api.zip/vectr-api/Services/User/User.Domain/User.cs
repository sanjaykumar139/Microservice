﻿using BuildingBlocks.Domain;
using Shared.Enum;

namespace User.Domain
{
    public class User : OperationLogEntity
    {
        #region Properties
        public string Title { get; set; }
        public string FirstName {  get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string CountryCode { get; set; }
        public string PhoneNumber { get; set; }
        public UserStatus Status { get; set; }
        #endregion
        #region Constructors
        public User()
        {
            // Default constructor
        }
        public User(Guid userId, string title, string firstName, string lastName, string email, string countryCode, string phoneNumber, UserStatus status)
        {
            SetId(userId == Guid.Empty ? Guid.NewGuid() : userId);
            SetIsNew(userId == Guid.Empty);
            SetIsDeleted(false);
            Title = title;
            FirstName = firstName;
            LastName = lastName;
            Email = email;
            CountryCode = countryCode;
            PhoneNumber = phoneNumber;
            Status = status;
        }
        #endregion
        #region Methods
        public static User Create(string title, string firstName, string lastName, string email, string countryCode, string phoneNumber, UserStatus status)
        {
            return new User(Guid.Empty, title, firstName, lastName, email, countryCode, phoneNumber, status);
        }
        public void ChangeStatus(UserStatus newStatus)
        {
            Status = newStatus;
        }
        public void Update(string title, string firstName, string lastName, string email, string countryCode, string phoneNumber)
        {
            Title = title;
            FirstName = firstName;
            LastName = lastName;
            Email = email;
            CountryCode = countryCode;
            PhoneNumber = phoneNumber;
        }
        public void Delete()
        {
            SetIsDeleted(true);
        }
        #endregion
    }
}