﻿using AutoMapper;

namespace User.Infrastructure.AutoMapperProfile
{
    public class FilterProfile : Profile
    {
        public FilterProfile()
        {
            
        }
    }
}
