﻿using Autofac;
using BuildingBlocks.Application;
using BuildingBlocks.Domain;
using BuildingBlocks.Session;
using BuildingBlocks.Utility;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Shared.Constants;
using User.Infrastructure.Configuration.DataAccess.Repository;

namespace User.Infrastructure.Configuration.DataAccess
{
    internal class DataAccessModule : Module
    {
        private readonly string _databaseConnectionString;

        internal DataAccessModule(string databaseConnectionString)
        {
            _databaseConnectionString = databaseConnectionString;
        }

        protected override void Load(ContainerBuilder builder)
        {
            builder.RegisterType<SqlServerConnectionFactory>()
                .As<ISqlConnectionFactory>()
                .WithParameter("connectionString", _databaseConnectionString)
                .InstancePerLifetimeScope();
            //register sessionManager and httcontext for it.
            builder.RegisterType<HttpContextAccessor>()
                    .As<IHttpContextAccessor>()
                    .SingleInstance();

            builder.RegisterType<SessionManager>()
                .As<SessionManager>()
                .InstancePerLifetimeScope();
            builder
            .Register(c =>
            {
                var dbContextOptionsBuilder = new DbContextOptionsBuilder<UserDb>();
                dbContextOptionsBuilder.UseSqlServer(_databaseConnectionString, sqlOption =>
                {
                    sqlOption.MigrationsHistoryTable(CommonConstants.DefaultMigration, CommonConstants.User);
                });
                return dbContextOptionsBuilder.Options;
            })
            .As<DbContextOptions<UserDb>>()
            .InstancePerLifetimeScope();
            builder.RegisterType<UserDb>().AsSelf()
                .InstancePerLifetimeScope();


            var infrastructureAssembly = typeof(UserDb).Assembly;

            builder.RegisterAssemblyTypes(infrastructureAssembly)
                .Where(type => type.Name.EndsWith("Repository"))
                .AsImplementedInterfaces()
                .InstancePerLifetimeScope()
                .FindConstructorsWith(new AllConstructorFinder());
            builder.RegisterGeneric(typeof(Repository<>)).As(typeof(IRepository<>)).InstancePerLifetimeScope();
            builder.RegisterGeneric(typeof(EntityRepository<>)).As(typeof(IEntityRepository<>)).InstancePerLifetimeScope();
        }
    }
}
