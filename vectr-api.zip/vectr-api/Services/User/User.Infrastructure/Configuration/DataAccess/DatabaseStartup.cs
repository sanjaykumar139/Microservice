﻿using Autofac;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace User.Infrastructure.Configuration.DataAccess
{
    public static class DatabaseStartup
    {
        public static void InitializeDb()
        {
            using (var scope = UserCompositionRoot.BeginLifetimeScope())
            {
                var dbContext = scope.Resolve<UserDb>();
                dbContext.InitDb();
            }
        }
    }
}
