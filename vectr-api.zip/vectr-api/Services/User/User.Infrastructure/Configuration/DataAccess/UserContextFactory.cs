﻿using Autofac;
using Microsoft.EntityFrameworkCore.Design;

namespace User.Infrastructure.Configuration.DataAccess
{
    public class UserContextFactory : IDesignTimeDbContextFactory<UserDb>
    {

        public UserDb CreateDbContext(string[] args)
        {
            return UserCompositionRoot.BeginLifetimeScope().Resolve<UserDb>();

        }
    }
}
