﻿using Autofac;
using BuildingBlocks.Contracts;
using MediatR;

namespace User.Infrastructure.Configuration.Processing
{
    internal class ServicesModule : Autofac.Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            builder.RegisterType<UnitOfWork>()
                .As<IUnitOfWork>()
                .InstancePerLifetimeScope();

            builder.RegisterGenericDecorator(
              typeof(UnitOfWorkCommandHandlerDecorator<>),
              typeof(IRequestHandler<>));

            builder.RegisterGenericDecorator(
                typeof(UnitOfWorkCommandHandlerWithResultDecorator<,>),
                typeof(IRequestHandler<,>));

            builder.RegisterInstance(AutoMapperConfig.Initialize()).SingleInstance();


        }
    }
}
