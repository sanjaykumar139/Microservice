﻿using Autofac;
using BuildingBlocks.Contracts;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Shared.Configurations;
using User.Infrastructure.Configuration.DataAccess;
using User.Infrastructure.Configuration.EventsBus;
using User.Infrastructure.Configuration.Mediation;
using User.Infrastructure.Configuration.Processing;

namespace User.Infrastructure.Configuration
{
    public class UserStartup
    {
        private static IContainer _container;

        public static void Initialize(AppSettings appSettings,          
            string connectionString, IEventsBus eventsBus=null, IConfiguration configuration = null, IHostEnvironment hostEnvironment = null)
        {

            ConfigureCompositionRoot(appSettings,
                connectionString,
                eventsBus,
                configuration,
                hostEnvironment);
            DatabaseStartup.InitializeDb();
            EventsBusStartup.Initialize();

        }

        private static void ConfigureCompositionRoot(AppSettings appSettings,
            string connectionString,
            IEventsBus eventsBus,
            IConfiguration configuration =null,
            IHostEnvironment hostEnvironment = null)
        {
            var containerBuilder = new ContainerBuilder();
            containerBuilder.RegisterInstance(appSettings);
            containerBuilder.RegisterModule(new EventsBusModule(eventsBus, appSettings.EventBusConfig));
            containerBuilder.RegisterModule(new DataAccessModule(connectionString));
            containerBuilder.RegisterModule(new MediatorModule(appSettings.LoggingEnabled));
            containerBuilder.RegisterModule(new ServicesModule());
            // Register IConfiguration
            containerBuilder.RegisterInstance(configuration).As<IConfiguration>().SingleInstance();
            _container = containerBuilder.Build();
            UserCompositionRoot.SetContainer(_container);
        }
    }
}
