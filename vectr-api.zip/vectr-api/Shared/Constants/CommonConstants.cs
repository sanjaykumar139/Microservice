﻿namespace Shared.Constants
{
    public static class CommonConstants
    {
        public const string User = "User";
        public const string DefaultMigration = "__EFMigrationsHistory";
        public const string MediaTypeJson = "application/json";
    }
}
