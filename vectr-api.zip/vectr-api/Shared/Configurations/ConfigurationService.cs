﻿//using Autofac;
//using Autofac.Core;
//using BuildingBlocks.Application;
//using BuildingBlocks.Filters;
//using FluentValidation.AspNetCore;
//using MediatR;
//using Microsoft.AspNetCore.Authentication.JwtBearer;
//using Microsoft.AspNetCore.Builder;
//using Microsoft.AspNetCore.Hosting;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.Extensions.Configuration;
//using Microsoft.Extensions.DependencyInjection;
//using Microsoft.Extensions.Hosting;
//using Microsoft.Extensions.Logging;
//using Microsoft.Identity.Web;
//using Microsoft.OpenApi.Models;
//using Sentry;
//using Shared.Configuration;
//using Shared.Configuration.Extension;
//using Shared.Configurations;
//using Shared.Configurations.Extension;
//using Shared.Constants;
//using Shared.Extensions;

//namespace Shared.Configuration
//{
//    public static class ConfigurationService
//    {

//        public static WebApplicationBuilder ConfigureServices(WebApplicationBuilder builder, string domain)
//        {
//            builder.Services.AddHttpContextAccessor();

//            builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
//                .AddMicrosoftIdentityWebApi(options =>
//                {
//                    builder.Configuration.Bind("AzureAd", options);
//                    options.Events = new JwtBearerEvents();
//                    options.Events.OnAuthenticationFailed = context =>
//                    {
//                        if (context.Exception.GetType() == typeof(System.Exception))
//                        {
//                            return Task.CompletedTask;
//                        }
//                        return Task.CompletedTask;
//                    };
//                }, options => { builder.Configuration.Bind("AzureAd", options); }, subscribeToJwtBearerMiddlewareDiagnosticsEvents: true);


//            builder.Services.AddCors(o => o.AddPolicy("corsPolicy", builder =>
//            {
//                builder.SetIsOriginAllowedToAllowWildcardSubdomains()
//                       .AllowAnyOrigin()
//                       .AllowAnyMethod()
//                       .AllowAnyHeader();
//            }));

//            builder.WebHost.UseSentry((options) =>
//            {
//                options.Dsn = builder.Configuration["Sentry:Dns"];
//                options.IncludeActivityData = true;
//                options.AttachStacktrace = true;
//                options.Debug = true;
//                options.SendDefaultPii = true;
//                options.MaxRequestBodySize = Sentry.Extensibility.RequestSize.Always;
//                options.Environment = builder.Environment.EnvironmentName;
//            });

//            // Load assembly for MediatR
//            var assembly = AppDomain.CurrentDomain.Load(domain + ".Infrastucture");

//            // Add MediatR
//            builder.Services.AddMediatR(assembly);


//            builder.Services.AddFluentValidation(mv => mv.RegisterValidatorsFromAssembly(AppDomain.CurrentDomain.Load(domain + ".Application")));
//            builder.Services.AddControllers(config => config.Filters.Add(typeof(ApiResultFilterAttribute)));
//            builder.Services.AddEndpointsApiExplorer();
//            builder.Services.AddRouting(options => options.LowercaseUrls = true);

//            var swagconfig = builder.Configuration.GetSection("SwaggerAuth");
//            ConfigSwagger(builder.Services, swagconfig);

//            builder.Services.AddLogging(configure =>
//            {
//                configure.ClearProviders();
//                configure.AddJsonConsole(opts =>
//                {
//                    opts.TimestampFormat = "s";
//                });
//            });
//            builder.Services.Configure<ApiBehaviorOptions>(config => config.SuppressModelStateInvalidFilter = false);
//            builder.Services.Configure<AppSettings>(builder.Configuration.GetSection("AppSettings"));
//            builder.Services.AddVersionSupport(builder.Configuration.GetSection("Version").Get<VersionSettings>());
//            builder.Services.RegisterSessionManager();
//            var appsettings = InitializeApp(builder, builder.Configuration);

//            return builder;

//        }

//        private static Action<HostBuilderContext, ContainerBuilder> ConfigureAutofacContainer(IModule mod)
//        {
//            {
//                return (context, builder) =>
//                {
//                    builder.RegisterModule(mod);
//                };
//            }
//        }


//        private static AppSettings InitializeApp(WebApplicationBuilder builder, IConfiguration configuration)
//        {
//            IConfigurationSection appSettings = configuration.GetSection("AppSettings");
//            var appSetting = appSettings.Get<AppSettings>();
//            // Register service to discovery
//            builder.Services.RegisterService(appSetting.ServiceConfig);

//            SetQueueByEnvironment(appSetting);
//            return appSetting;
//        }

//        public static void SetQueueByEnvironment(AppSettings appSetting)
//        {
//            //appSetting.RabitMQConfiguration.UserName =
//            //    Environment.GetEnvironmentVariable(CommonEnvVariables.RabbitMQUserName) ?? string.Empty;
//            //appSetting.RabitMQConfiguration.Password =
//            //    Environment.GetEnvironmentVariable(CommonEnvVariables.RabbitMQPassword) ?? string.Empty;
//            //appSetting.RabitMQConfiguration.HostName =
//            //    Environment.GetEnvironmentVariable(CommonEnvVariables.RabbitMQHost) ?? string.Empty;
//            //appSetting.RabitMQConfiguration.Port =
//            //    Convert.ToUInt16(Environment.GetEnvironmentVariable(CommonEnvVariables.RabbitMQPort));
//        }

//        private static void ConfigSwagger(IServiceCollection serviceCollection, IConfigurationSection swagconfig)
//        {
//            // Add SwaggerGen for API documentation
//            serviceCollection.AddSwaggerGen(c =>
//            {
//                c.OperationFilter<SwaggerHeaderId>();
//                c.AddSecurityDefinition("oauth2", new OpenApiSecurityScheme
//                {
//                    Description = "Swagger Auth",
//                    Name = "oauth2",
//                    Type = SecuritySchemeType.OAuth2,
//                    Flows = new OpenApiOAuthFlows
//                    {
//                        AuthorizationCode = new OpenApiOAuthFlow
//                        {
//                            AuthorizationUrl = new Uri(swagconfig["AuthorityEndPoint"] ?? string.Empty),
//                            TokenUrl = new Uri(swagconfig["TokenEndpoint"] ?? string.Empty),
//                            Scopes = new Dictionary<string, string>
//                    {
//                        { swagconfig["Scope"], "" }
//                    }
//                        }
//                    }
//                });
//                c.AddSecurityRequirement(new OpenApiSecurityRequirement
//        {
//            {
//                new OpenApiSecurityScheme
//                {
//                    Reference = new OpenApiReference { Type = ReferenceType.SecurityScheme, Id = "oauth2" }
//                },
//                new[] { swagconfig["Scope"] }
//            }
//        });
//            });
//        }

//        public static void ConfigureApp(WebApplication app, IConfigurationSection swagconfig)
//        {
//            app.UseSentryTracing();
//            SentrySdk.CaptureMessage($"Service started at: {DateTime.UtcNow}");
//            app.UseCors("corsPolicy");

//            app.UseHttpsRedirection();
//            app.UseAuthentication();
//            app.UseAuthorization();
//            app.UseSwagger();
//            app.UseSwaggerUI(options =>
//            {
//                options.DisplayRequestDuration();
//                options.EnableTryItOutByDefault();

//                options.OAuthClientId(swagconfig["ClientId"]);
//                options.OAuthUsePkce();
//                options.OAuthScopeSeparator(" ");
//            });
//            app.MapControllers();
//        }
//    }
//}

