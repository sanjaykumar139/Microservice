﻿namespace Shared.Configurations.Extension
{
    public class VersionSettings
    {
        public int Major { get; set; }
        public int Minor { get; set; }
    }
}
