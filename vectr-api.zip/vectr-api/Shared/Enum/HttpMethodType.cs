﻿namespace Shared.Enum
{
    public enum HttpMethodType
    {
        Get,
        Post,
        Put,
        Delete,
        FormUrlEncoded
    }
}
