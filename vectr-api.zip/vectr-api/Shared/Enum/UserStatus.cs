﻿namespace Shared.Enum
{
    public enum UserStatus
    {
        Inactive = 0,
        Active = 1
    }
}
